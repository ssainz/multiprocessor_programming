java -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 2
java -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 4
java -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 8
java -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 16

package edu.vt.ece.hw4.barriers;

public interface Barrier {



    void enter(int threadID);

    void reset();

}

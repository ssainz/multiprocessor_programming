java -ea -cp build/libs/hw2.jar edu.vt.ece.Test TreePeterson

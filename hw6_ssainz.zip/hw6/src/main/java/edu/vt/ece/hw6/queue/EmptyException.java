package edu.vt.ece.hw6.queue;

public class EmptyException extends Exception{


}

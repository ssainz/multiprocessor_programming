java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 2
java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 4
java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 8
java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 16
java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 32
java -ea -cp build/libs/hw2.jar edu.vt.ece.Test2 TreePeterson 64

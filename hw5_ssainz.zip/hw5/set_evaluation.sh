java -cp build/libs/hw5.jar edu.vt.ece.hw5.set.Benchmark  64000  CoarseList
java -cp build/libs/hw5.jar edu.vt.ece.hw5.set.Benchmark  64000  FineList
java -cp build/libs/hw5.jar edu.vt.ece.hw5.set.Benchmark  64000  LazyList
java -cp build/libs/hw5.jar edu.vt.ece.hw5.set.Benchmark  64000  LockFreeList
java -cp build/libs/hw5.jar edu.vt.ece.hw5.set.Benchmark  64000  OptimisticList
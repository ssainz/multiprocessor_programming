package edu.vt.ece.locks;

public interface Timestamp {
    public boolean compare(Timestamp t);

}

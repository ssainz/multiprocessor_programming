package edu.vt.ece.bench;

/**
 * 
 * @author Balaji Arun
 */
public interface ThreadId {

	public int getThreadId();
	
}

package edu.vt.ece.hw4.bench;

/**
 * 
 * @author Balaji Arun
 */
public interface ThreadId {

	int getThreadId();
	
}
